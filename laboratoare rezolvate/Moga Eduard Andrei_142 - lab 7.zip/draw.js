function drawTable(nrows, ncols) {
   let container = document.getElementById('container');
   let table = document.createElement('table');
   for (let i = 0; i < nrows; i++) {
      let tr = document.createElement('tr');
      for (let j = 0; j < ncols; j++) {
         let td = document.createElement('td');
         td.classList.add(`r${i}`, `c${j}`);
         tr.appendChild(td);
      }
      table.appendChild(tr);
   }
   container.appendChild(table);
}

function colorCol(column, color) {
   let cells = document.querySelectorAll(`.c${column}`);
   cells.forEach(cell => cell.style.backgroundColor = color);
}

function colorRow(row, color) {
   let cells = document.querySelectorAll(`.r${row}`);
   cells.forEach(cell => cell.style.backgroundColor = color);
}

function rainbow(target) {
   let colors = ["rgb(255, 0, 0)", "rgb(255, 154, 0)", "rgb(240, 240, 0)", "rgb(79, 220, 74)", "rgb(63, 218, 216)", "rgb(47, 201, 226)", "rgb(28, 127, 238)", "rgb(95, 21, 242)", "rgb(186, 12, 248)", "rgb(251, 7, 217)"];
   if (target === 'vertical') {
      colors.forEach((color, index) => colorCol(index, color));
   } else if (target === 'horizontal') {
      colors.forEach((color, index) => colorRow(index, color));
   }
}

function getNthChild(element, n) {
   return element.children[n];
}

function drawPixel(row, col, color) {
   let cell = document.querySelector(`.r${row}.c${col}`);
   if (cell) {
      cell.style.backgroundColor = color;
   }
}

function drawLine(r1, c1, r2, c2, color) {
   if (r1 === r2) {
      for (let c = c1; c <= c2; c++) {
         drawPixel(r1, c, color);
      }
   } else if (c1 === c2) {
      for (let r = r1; r <= r2; r++) {
         drawPixel(r, c1, color);
      }
   }
}

function drawRect(r1, c1, r2, c2, color) {
   drawLine(r1, c1, r1, c2, color);
   drawLine(r1, c2, r2, c2, color);
   drawLine(r2, c2, r2, c1, color);
   drawLine(r2, c1, r1, c1, color);
}

function drawPixelExt(row, col, color) {
   let table = document.querySelector('table');
   let nrows = table.rows.length;
   let ncols = table.rows[0].cells.length;

   if (row >= nrows) {
      for (let i = nrows; i <= row; i++) {
         let tr = document.createElement('tr');
         for (let j = 0; j < ncols; j++) {
            let td = document.createElement('td');
            td.classList.add(`r${i}`, `c${j}`);
            tr.appendChild(td);
         }
         table.appendChild(tr);
      }
   }

   if (col >= ncols) {
      for (let i = 0; i < table.rows.length; i++) {
         for (let j = ncols; j <= col; j++) {
            let td = document.createElement('td');
            td.classList.add(`r${i}`, `c${j}`);
            table.rows[i].appendChild(td);
         }
      }
   }

   drawPixel(row, col, color);
}

function drawPixelAmount(row, col, color, amount) {
   let cell = document.querySelector(`.r${row}.c${col}`);
   if (cell) {
      let initialColor = getComputedStyle(cell).backgroundColor;
      let newColorArray = color.match(/\d+/g);
      let initialColorArray = initialColor.match(/\d+/g);

      let r = colorMixer(parseInt(initialColorArray[0]), parseInt(newColorArray[0]), amount);
      let g = colorMixer(parseInt(initialColorArray[1]), parseInt(newColorArray[1]), amount);
      let b = colorMixer(parseInt(initialColorArray[2]), parseInt(newColorArray[2]), amount);

      cell.style.backgroundColor = `rgb(${r},${g},${b})`;
   }
}

function delRow(row) {
   let table = document.querySelector('table');
   if (table.rows[row]) {
      table.deleteRow(row);
   }
}

function delCol(col) {
   let table = document.querySelector('table');
   for (let i = 0; i < table.rows.length; i++) {
      if (table.rows[i].cells[col]) {
         table.rows[i].deleteCell(col);
      }
   }
}

function shiftRow(row, pos) {
   let cells = document.querySelectorAll(`.r${row}`);
   let cellArray = Array.from(cells);
   let shiftedArray = cellArray.splice(-pos).concat(cellArray);
   shiftedArray.forEach((cell, index) => {
      cell.classList.remove(`c${index}`);
      cell.classList.add(`c${(index + pos) % cellArray.length}`);
   });
}

function jumble() {
   let table = document.querySelector('table');
   for (let i = 0; i < table.rows.length; i++) {
      let pos = Math.floor(Math.random() * table.rows[i].cells.length);
      shiftRow(i, pos);
   }
}

function transpose() {
   let table = document.querySelector('table');
   let newTable = document.createElement('table');
   let nrows = table.rows.length;
   let ncols = table.rows[0].cells.length;

   for (let i = 0; i < ncols; i++) {
      let tr = document.createElement('tr');
      for (let j = 0; j < nrows; j++) {
         let td = document.createElement('td');
         td.classList.add(`r${i}`, `c${j}`);
         td.style.backgroundColor = getComputedStyle(table.rows[j].cells[i]).backgroundColor;
         tr.appendChild(td);
      }
      newTable.appendChild(tr);
   }

   table.parentNode.replaceChild(newTable, table);
}

function flip(element) {
   let children = Array.from(element.children);
   children.reverse().forEach(child => element.appendChild(child));
}

function mirror() {
   let table = document.querySelector('table');
   let nrows = table.rows.length;
   let ncols = table.rows[0].cells.length;

   for (let i = 0; i < nrows; i++) {
      for (let j = 0; j < Math.floor(ncols / 2); j++) {
         let leftCell = table.rows[i].cells[j];
         let rightCell = table.rows[i].cells[ncols - j - 1];
         rightCell.style.backgroundColor = getComputedStyle(leftCell).backgroundColor;
      }
   }
}

function smear(row, col, amount) {
   let cell = document.querySelector(`.r${row}.c${col}`);
   if (cell) {
      let color = getComputedStyle(cell).backgroundColor;
      for (let i = 1; i <= 3; i++) {
         drawPixelAmount(row, col + i, color, amount / Math.pow(2, i));
      }
   }
}

window.onload = function() {
   const rows = 100;
   const cols = 100;
   drawTable(rows, cols);
   rainbow('vertical');

};
